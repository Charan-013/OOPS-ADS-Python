class Node:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

class BinaryTree:
    def zigzag_traversal(self, root):
        """
        Perform a zigzag (spiral order) traversal of the binary tree.
        
        Args:
            root (Node): The root node of the tree.
            
        Returns:
            List[List[int]]: List of lists of node values per level in zigzag order.
        """
        # TODO: Implement zigzag traversal.
        return []

    def max_width(self, root):
        """
        Compute the maximum width (max number of nodes at any level) of the tree.
        
        Args:
            root (Node): The root node.
            
        Returns:
            int: The maximum width.
        """
        # TODO: Implement maximum width computation.
        return 0

    def diameter(self, root):
        """
        Compute the diameter of the tree (the longest path between any two nodes).
        
        Args:
            root (Node): The root node.
            
        Returns:
            int: The diameter (node count or edge count as per design).
        """
        # TODO: Implement diameter calculation.
        return 0

    def lowest_common_ancestor(self, root, val1, val2):
        """
        Find the lowest common ancestor (LCA) of two nodes by value.
        
        Args:
            root (Node): The root node.
            val1 (int): The value of the first node.
            val2 (int): The value of the second node.
            
        Returns:
            Node or None: The LCA node, or None if one or both values are not present.
        """
        # TODO: Implement lowest common ancestor finder.
        return None

class BinarySearchTree(BinaryTree):
    def kth_smallest(self, root, k):
        """
        Find the kth smallest element in the BST using in-order traversal.
        
        Args:
            root (Node): The root node of the BST.
            k (int): The kth order statistic.
            
        Returns:
            int: The kth smallest element's value, or -1 if k is out of bounds.
        """
        # TODO: Implement kth smallest finder.
        return -1

    def inorder_successor(self, root, target):
        """
        Find the inorder successor of a given target node in the BST.
        
        Args:
            root (Node): The root of the BST.
            target (Node): The target node.
            
        Returns:
            Node or None: The inorder successor node, or None if none exists.
        """
        # TODO: Implement inorder successor finder.
        return None

    def merge_trees(self, root1, root2):
        """
        Merge two BSTs into a new BST that maintains BST properties.
        
        Args:
            root1 (Node): The root of the first BST.
            root2 (Node): The root of the second BST.
            
        Returns:
            Node or None: The root of the merged BST.
        """
        # TODO: Implement merging of two BSTs.
        return None

    def find_closest_value(self, root, target):
        """
        Find the value in the BST that is closest to the given target value.
        
        Args:
            root (Node): The root of the BST.
            target (int): The target value.
            
        Returns:
            int: The closest value found, or -1 if the tree is empty.
        """
        # TODO: Implement closest value search.
        return -1

class BalancedBST(BinarySearchTree):
    def split_bst(self, root, key):
        """
        Split the balanced BST into two BSTs by a pivot key.
        
        Args:
            root (Node): The root of the BST.
            key (int): The pivot key.
            
        Returns:
            Tuple[Node or None, Node or None]: (tree_less, tree_greater_or_equal)
        """
        # TODO: Implement BST split preserving balance.
        return (None, None)

    def join_bst(self, root1, root2):
        """
        Join two balanced BSTs into one balanced BST.
        Assumes every element in root1 is less than every element in root2.
        
        Args:
            root1 (Node): The first BST root.
            root2 (Node): The second BST root.
            
        Returns:
            Node or None: The root of the joined balanced BST.
        """
        # TODO: Implement joining of two balanced BSTs.
        return None

    def find_median(self, root):
        """
        Find the median element in the balanced BST.
        (May require augmentation such as storing subtree sizes.)
        
        Args:
            root (Node): The root of the BST.
            
        Returns:
            int: The median value, or -1 if the tree is empty.
        """
        # TODO: Implement median finder.
        return -1

    def range_sum_query(self, root, low, high):
        """
        Compute the sum of all node values within the inclusive range [low, high].
        (May use augmented subtree sum values for efficiency.)
        
        Args:
            root (Node): The root of the BST.
            low (int): The lower bound.
            high (int): The upper bound.
            
        Returns:
            int: The sum of values in the specified range.
        """
        # TODO: Implement range sum query.
        return 0
