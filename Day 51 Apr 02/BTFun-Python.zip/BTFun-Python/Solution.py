class BTNode:
    def __init__(self, data, left=None, right=None):
        self.data = data
        self.left = left
        self.right = right

    def __str__(self):
        # For a simple representation
        return str(self.data)


# 1. copy: Return a deep copy of the tree.
def copy_tree(t):
    pass

# 2. replace: Replace all occurrences of old_value with new_value.
#    Return the count of nodes replaced.
def replace(t, old_value, new_value):
    pass


# 3. countNodesAtDepth: Count the number of nodes at the given depth.
def countNodesAtDepth(t, depth):
    pass


# 4. allSame: Return True if every value in the tree is the same.
def allSame(t):
    pass


# 5. leafList: Return a list of the data values in the leaves of the tree.
def leafList(t):
    pass


# 6. reflect: Modify the tree so that it is reflected horizontally.
def reflect(t):
    pass


# 7. condense: Remove nodes with exactly one child.
def condense(t):
    pass


# Function to perform pre-order traversal of the tree.
def print_preorder(t):
    pass


