import sys

class SortedSet:
    def __init__(self):
        # TODO: initialize internal storage (e.g., a list)
        pass

    def add(self, element):
        # TODO: insert element in sorted order; ignore duplicates
        pass

    def remove(self, element):
        # TODO: remove element if exists
        pass

    def contains(self, element):
        # TODO: check membership
        pass

    def size(self):
        # TODO: return number of elements
        pass

    def isEmpty(self):
        # TODO: return True if empty
        pass

    def clear(self):
        # TODO: clear all elements
        pass

    def toArray(self):
        # TODO: return a shallow copy of elements in sorted order
        pass

    def first(self):
        # TODO: return the lowest element
        pass

    def last(self):
        # TODO: return the highest element
        pass

    def headSet(self, toElement):
        # TODO: return new SortedSet of elements < toElement
        pass

    def tailSet(self, fromElement):
        # TODO: return new SortedSet of elements >= fromElement
        pass

    def subSet(self, fromElement, toElement):
        # TODO: return new SortedSet of elements in [fromElement, toElement)
        pass


def main():
    set_obj = SortedSet()
    for line in sys.stdin:
        parts = line.strip().split()
        if not parts:
            continue
        cmd = parts[0]
        # TODO: dispatch commands to methods
        if cmd == 'add':
            # TODO: parse and call set_obj.add
            pass
        elif cmd == 'remove':
            pass
        elif cmd == 'contains':
            pass
        elif cmd == 'size':
            pass
        elif cmd == 'isEmpty':
            pass
        elif cmd == 'clear':
            pass
        elif cmd == 'toArray':
            pass
        elif cmd == 'first':
            pass
        elif cmd == 'last':
            pass
        elif cmd == 'headSet':
            pass
        elif cmd == 'tailSet':
            pass
        elif cmd == 'subSet':
            pass
        elif cmd == 'exit':
            break
        else:
            print(f"Unknown command: {cmd}")

if __name__ == '__main__':
    main()
