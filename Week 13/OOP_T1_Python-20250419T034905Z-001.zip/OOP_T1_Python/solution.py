class Node:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

class BinaryTree:
    def max_sum_non_adjacent(self, root):
        return 0

    def burning_tree(self, root, start):
        return 0

class BinarySearchTree(BinaryTree):
    def has_triplet_with_sum(self, root, target):
        return False

    def bst_to_doubly_linked_list(self, root):
        return None

    def longest_consecutive(self, root):
        return 0

    def count_nodes_in_range(self, root, low, high, even_only):
        return 0

class BalancedBST(BinarySearchTree):
    def sorted_list_to_avl(self, sorted_list):
        return None

    def min_sum_path(self, root):
        return 0

    def sum_at_prime_levels(self, root):
        return 0

    def replace_node_rb_tree(self, root, old_val, new_val):
        return None

    def rb_tree_height(self, root):
        return 0

    def avl_to_max_heap(self, root):
        return None




