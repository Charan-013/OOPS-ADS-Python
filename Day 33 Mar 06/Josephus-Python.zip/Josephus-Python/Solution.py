class DoublyCircularLL:
    pass

class Josephus:
    def josephusDCLL(self, size, rotation):
        pass
