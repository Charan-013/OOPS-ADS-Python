import sys
import math
from functools import cmp_to_key

class Point:
    pass

class LineSegment:
    def __init__(self, p, q):
        if p is None or q is None:
            raise ValueError("Argument to LineSegment constructor is None")
        if p == q:
            raise ValueError(f"Both endpoints are the same point: {p}")
        self.p = p
        self.q = q

    def __str__(self):
        return f"{self.p} -> {self.q}"

    def __repr__(self):
        return str(self)


class FastCollinearPoints:
    pass


def main():


main()
