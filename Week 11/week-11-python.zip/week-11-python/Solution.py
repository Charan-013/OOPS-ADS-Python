# Define the Node class used by both BinaryTree and BinarySearchTree.
class Node:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

# BinaryTree with methods: levelOrder, isComplete, countLeaves, and pathSum.
class BinaryTree:
    def __init__(self, root=None):
        self.root = root

    # 1. Level Order Traversal: returns list of lists of node values per level.
    def levelOrder(self):
        pass
        # Todo

    # 2. Check Completeness: returns True if the tree is complete.
    def isComplete(self):
        pass
        # Todo

    # 3. Count Leaf Nodes: returns the number of leaf nodes.
    def countLeaves(self):
        pass
        # Todo

    # 4. Root-to-Leaf Path Sum: returns True if a root-to-leaf path equals target sum.
    def pathSum(self, target):
        pass
        # Todo

# BinarySearchTree (inherits from BinaryTree) with methods: validateBST, rangeSearch, balance.
class BinarySearchTree(BinaryTree):
    def __init__(self, root=None):
        super().__init__(root)

    # 5. Validate BST: returns True if the tree satisfies BST properties.
    def validateBST(self):
        pass
        # Todo

    # 6. Range Search: returns a sorted list of node values within [low, high].
    def rangeSearch(self, low, high):
        pass
        # Todo

    # 7. Balance BST: rebuilds the tree so that it is balanced.
    def balance(self):
        pass
        # Todo
