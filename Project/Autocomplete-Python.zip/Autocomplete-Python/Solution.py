import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

class Term:
    pass

class BinarySearchDeluxe:
    pass

class Autocomplete:
    pass

def read_file(filename):
    with open(filename, 'r', encoding='utf-8') as file:
        n = int(file.readline().strip())
        terms = []
        for _ in range(n):
            line = file.readline().strip().split('\t')
            weight = int(line[0])
            query = line[1]
            terms.append(Term(query, weight))
        return terms


def main():
    filename = input().strip()
    terms = read_file(filename)
    k = int(input().strip())
    autocomplete = Autocomplete(terms)

    while True:
        try:
            prefix = input().strip()
            results = autocomplete.all_matches(prefix)
            print(f"{autocomplete.number_of_matches(prefix)} matches")
            for i in range(min(k, len(results))):
                print(results[i])
        except EOFError:
            break


main()