import math

class Point2D:
    def __init__(self, x, y):
        if math.isinf(x) or math.isinf(y):
            raise ValueError("Coordinates must be finite")
        if math.isnan(x) or math.isnan(y):
            raise ValueError("Coordinates cannot be NaN")
        # convert -0.0 to 0.0
        self._x = 0.0 if x == 0.0 else x
        self._y = 0.0 if y == 0.0 else y

    @property
    def x(self):
        return self._x

    @property
    def y(self):
        return self._y

    def distance_to(self, that):
        return math.sqrt(self.distance_squared_to(that))

    def distance_squared_to(self, that):
        dx = self.x - that.x
        dy = self.y - that.y
        return dx * dx + dy * dy

    def __eq__(self, other):
        if not isinstance(other, Point2D):
            return False
        return self.x == other.x and self.y == other.y

    def __hash__(self):
        return hash((self.x, self.y))

    def __lt__(self, other):
        # compare by y-coordinate; break ties by x-coordinate
        if self.y != other.y:
            return self.y < other.y
        return self.x < other.x

    def __repr__(self):
        return f"({self.x}, {self.y})"
