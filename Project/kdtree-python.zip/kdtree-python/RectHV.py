import math
from Point2D import Point2D

class RectHV:
    def __init__(self, xmin, ymin, xmax, ymax):
        if any(math.isnan(v) for v in (xmin, ymin, xmax, ymax)):
            raise ValueError("Coordinates cannot be NaN")
        if xmax < xmin or ymax < ymin:
            raise ValueError("Invalid rectangle: xmax < xmin or ymax < ymin")
        self._xmin = xmin
        self._ymin = ymin
        self._xmax = xmax
        self._ymax = ymax

    @property
    def xmin(self):
        return self._xmin

    @property
    def ymin(self):
        return self._ymin

    @property
    def xmax(self):
        return self._xmax

    @property
    def ymax(self):
        return self._ymax

    def width(self):
        return self._xmax - self._xmin

    def height(self):
        return self._ymax - self._ymin

    def contains(self, p):
        return (self._xmin <= p.x <= self._xmax) and (self._ymin <= p.y <= self._ymax)

    def intersects(self, that):
        return (self._xmax >= that.xmin and self._ymax >= that.ymin and
                that.xmax >= self._xmin and that.ymax >= self._ymin)

    def distance_squared_to(self, p):
        dx = 0.0
        dy = 0.0
        if p.x < self._xmin:
            dx = p.x - self._xmin
        elif p.x > self._xmax:
            dx = p.x - self._xmax
        if p.y < self._ymin:
            dy = p.y - self._ymin
        elif p.y > self._ymax:
            dy = p.y - self._ymax
        return dx * dx + dy * dy

    def distance_to(self, p):
        return math.sqrt(self.distance_squared_to(p))

    def __repr__(self):
        return f"[{self._xmin}, {self._xmax}] x [{self._ymin}, {self._ymax}]"
