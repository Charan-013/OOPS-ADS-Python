import math
from Point2D import Point2D
from RectHV import RectHV

class KdTree:
    pass

# Example usage:
if __name__ == '__main__':
    tree = KdTree()
    # Insert a few sample points.
    sample_points = []
    try:
        while True:
            lines = input().split(" ")
            a = float(lines[0])
            b = float(lines[1])
            sample_points.append(Point2D(a, b))
    except:
        pass
    
    for p in sample_points:
        tree.insert(p)

    print("Size: ", tree.size())
    # Range search example.
    query_rect = RectHV(0.0, 0.0, 0.5, 0.5)
    in_range = tree.range(query_rect)
    for p in in_range:
        print(p)

    # Nearest neighbor example.
    query_point = Point2D(0.65, 0.3)
    nearest = tree.nearest(query_point)
    print("Nearest to", query_point, "is", nearest)


