class BinaryTree:
    class BTNode:
        def __init__(self, data):
            self.data = data
            self.left = None
            self.right = None

        def __str__(self):
            return str(self.data)

    def __init__(self, element=None, left_tree=None, right_tree=None):
        # When element is None, we create an empty tree.
        if element is None:
            self.root = None
        else:
            self.root = BinaryTree.BTNode(element)
            if left_tree is not None:
                self.root.left = left_tree.root
            if right_tree is not None:
                self.root.right = right_tree.root

    def countInternal(self):
        """Returns the number of internal (non-leaf) nodes in the tree."""
        pass



    def height(self):
        """Returns the height of the tree.
        Height is defined as the number of nodes on the longest path from the root down to a leaf.
        """
        pass



    def isPerfect(self):
        """Returns True if the tree is perfect.
        A perfect tree is one in which every internal node has two children and all leaves are at the same depth.
        """
        pass

    def __str__(self):
        lines = []
        self._preOrderTraversal(self.root, 0, lines)
        return "\n".join(lines)

    def _preOrderTraversal(self, node, depth, lines):
        indent = "  " * (depth - 1) if depth > 0 else ""
        if node is None:
            lines.append(indent + "null")
        else:
            lines.append(indent + str(node))
            self._preOrderTraversal(node.left, depth + 1, lines)
            self._preOrderTraversal(node.right, depth + 1, lines)

