class Node:
    """Represents a node in the Binary Search Tree."""
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

class BinarySearchTree:
    """A Binary Search Tree implementation."""
    def __init__(self):
        pass

    def is_empty(self):
        pass

    def add(self, data):
        pass

    def contains(self, data):
        pass

    def max(self):
        pass

    def size(self):
        pass

    def in_order(self):
        pass

    def pre_order(self):
        pass

